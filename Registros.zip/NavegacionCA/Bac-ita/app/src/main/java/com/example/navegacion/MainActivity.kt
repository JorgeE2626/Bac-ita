package com.example.navegacion

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.navegacion.ui.theme.RegistroRanchoActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Redirige automáticamente a Registro Rancho
        startActivity(Intent(this, RegistroRanchoActivity::class.java))
        finish()
    }
}